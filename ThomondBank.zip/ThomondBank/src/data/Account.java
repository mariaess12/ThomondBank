package data;

import java.security.PublicKey;
import java.time.LocalDate;

public abstract class Account {
private int id;
private int custNo;
double balance =0;
private LocalDate dateCreated;
private static double AIR;

public Account(int id, int custNo, double balance, LocalDate dateCreated, double AIR) {
    this.id = id;
    this.custNo = custNo;
    this.balance = 0.0;
    this.dateCreated = dateCreated;
    Account.AIR = AIR;
}

    public static double getAIR() {
        return AIR;
    }

    public static void setAIR(double AIR) {
        Account.AIR = AIR;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustNo() {
        return custNo;
    }

    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public LocalDate getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        } else {
        }
    }

    public abstract boolean withdraw(double amount);

}
