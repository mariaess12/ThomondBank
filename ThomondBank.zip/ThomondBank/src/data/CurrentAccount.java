package data;

import java.time.LocalDate;

public class CurrentAccount extends Account {
    private static double AIR = 0.005;
    private double overdraftLimit;



    public CurrentAccount(int id, int custNo, double balance, LocalDate dateCreated, double AIR,double overdraftLimit) {
        super(id, custNo, balance, dateCreated, AIR);
        this.overdraftLimit = overdraftLimit;

    }
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && (balance + overdraftLimit) >= amount) {
            balance -= amount;
            return true;
        } else {
            return false;
        }
    }
    public void setOverdraftLimit(double limit) {
        this.overdraftLimit = limit;
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }
    public static void setAIR(double AIR) {
        CurrentAccount.AIR = AIR;
    }
    public static double getAIR() {
        return AIR;
    }

}
