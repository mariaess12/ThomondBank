package data;

import java.time.LocalDate;

public class BankStaff extends Person{
    private int empNo;
    private String jobTitle;

    public BankStaff(String firstName, String lastName, String address, LocalDate dob, int empNo) {
        super(firstName, lastName, address, dob);
    }

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
}
