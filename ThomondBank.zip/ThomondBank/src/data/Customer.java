package data;

import java.time.LocalDate;

public class Customer extends Person{

    private int custNo;

    public Customer(String firstName, String lastName, String address, LocalDate dob) {
        super(firstName, lastName, address, dob);
    }

    public int getCustNo() {
        return custNo;
    }

    public void setCustNo(int custNo) {
        this.custNo = custNo;
    }
}
