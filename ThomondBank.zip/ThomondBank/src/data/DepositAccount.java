package data;

import java.time.LocalDate;

public class DepositAccount extends Account {

    private static double AIR = 0.02;

    public DepositAccount(int id, int custNo, double balance, LocalDate dateCreated) {
        super(id, custNo, balance, dateCreated, AIR);
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        } else {
            return false;
        }
    }

    public static void setAIR(double AIR) {
        DepositAccount.AIR = AIR;
    }

}

