package gui;

import data.Account;
import data.CurrentAccount;
import data.DepositAccount;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;

public class ThomondBanks {
    //Maria Silva Souza K00293878

    private DepositAccount depositAccount;
    private CurrentAccount currentAccount;
    private double idNo;
    private JPanel root;
    private JTabbedPane atmUserTabbedPane;
    private JTextField accountIdTextField;
    private JRadioButton depositAccountRadioButton;
    private JRadioButton currentAccountRadioButton;
    private JButton depositButton;
    private JButton withdrawButton;
    private JButton checkBalanceButton;
    private JButton logoutButton;
    private JButton createNewAccountButton;
    private JButton changeAirButton;
    private JButton changeOverdraftLimitButton;

    public static ArrayList<Account> thomondAccounts = new ArrayList<>();

    public ThomondBanks() {
        populateMyAccounts();

        depositButton.setVisible(false);
        withdrawButton.setVisible(false);
        checkBalanceButton.setVisible(false);
        logoutButton.setVisible(false);

        accountIdTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(accountIdTextField.getText());
                    Account foundAccount = null;
                    for (Account account : thomondAccounts) {
                        if (account.getId() == id) {
                            foundAccount = account;
                            break;
                        }
                    }
                    if (foundAccount != null) {
                        if (foundAccount instanceof DepositAccount) {
                            depositAccount = (DepositAccount) foundAccount;
                            depositAccountRadioButton.setSelected(true);
                        } else if (foundAccount instanceof CurrentAccount) {
                            currentAccount = (CurrentAccount) foundAccount;
                            currentAccountRadioButton.setSelected(true);
                        }
                        depositButton.setVisible(true);
                        withdrawButton.setVisible(true);
                        checkBalanceButton.setVisible(true);
                        logoutButton.setVisible(true);
                    } else {
                        depositButton.setVisible(false);
                        withdrawButton.setVisible(false);
                        checkBalanceButton.setVisible(false);
                        logoutButton.setVisible(false);

                        JOptionPane.showMessageDialog(null, "Try Again Please.");
                    }
                } catch (NumberFormatException ex) {
                    depositButton.setVisible(false);
                    withdrawButton.setVisible(false);
                    checkBalanceButton.setVisible(false);
                    logoutButton.setVisible(false);

                    JOptionPane.showMessageDialog(null, "Must be numeric");
                }
            }
        });
        depositAccountRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                depositAccount = new DepositAccount(1, 1, 1000.0, LocalDate.now());
            }
        });

        currentAccountRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentAccount = new CurrentAccount(2, 2, 2000.0, LocalDate.now(), CurrentAccount.getAIR(), 500.0);
            }
        });

        ButtonGroup group = new ButtonGroup();
        group.add(depositAccountRadioButton);
        group.add(currentAccountRadioButton);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                depositButton.setVisible(false);
                withdrawButton.setVisible(false);
                checkBalanceButton.setVisible(false);
                logoutButton.setVisible(false);
                accountIdTextField.setText("");
            }
        });

        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (depositAccountRadioButton.isSelected() && depositAccount != null) {
                    String amountStr = JOptionPane.showInputDialog(null, "Enter deposit amount:", "Deposit", JOptionPane.PLAIN_MESSAGE);
                    if (amountStr != null) {
                        try {
                            double amount = Double.parseDouble(amountStr);
                            depositAccount.deposit(amount);
                            JOptionPane.showMessageDialog(null, "Balance: €" + depositAccount.getBalance());
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else if (currentAccountRadioButton.isSelected() && currentAccount != null) {
                    String amountStr = JOptionPane.showInputDialog(null, "Enter amount to deposit:", "Deposit", JOptionPane.PLAIN_MESSAGE);
                    if (amountStr != null) {
                        try {
                            double amount = Double.parseDouble(amountStr);
                            currentAccount.deposit(amount);
                            JOptionPane.showMessageDialog(null, "Balance: €" + currentAccount.getBalance());
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Select an account first.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (depositAccountRadioButton.isSelected() && depositAccount != null) {
                    String amountStr = JOptionPane.showInputDialog(null, "Enter withdraw amount:", "Withdraw", JOptionPane.PLAIN_MESSAGE);
                    if (amountStr != null) {
                        try {
                            double amount = Double.parseDouble(amountStr);
                            if (depositAccount.withdraw(amount)) {
                                JOptionPane.showMessageDialog(null, "Balance: €" + depositAccount.getBalance());
                            } else {
                                JOptionPane.showMessageDialog(null, "Try again", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else if (currentAccountRadioButton.isSelected() && currentAccount != null) {

                    String amountStr = JOptionPane.showInputDialog(null, "Enter withdraw amount:", "Withdraw", JOptionPane.PLAIN_MESSAGE);
                    if (amountStr != null) {
                        try {
                            double amount = Double.parseDouble(amountStr);
                            if (currentAccount.withdraw(amount)) {
                                JOptionPane.showMessageDialog(null, "Balance: €" + currentAccount.getBalance());
                            } else {
                                JOptionPane.showMessageDialog(null, "Try again", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an account first.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        checkBalanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (depositAccountRadioButton.isSelected() && depositAccount != null) {
                    JOptionPane.showMessageDialog(null, "Current balance: €" + depositAccount.getBalance());
                } else if (currentAccountRadioButton.isSelected() && currentAccount != null) {
                    JOptionPane.showMessageDialog(null, "Current balance: €" + currentAccount.getBalance());
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an account first.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        createNewAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String accountType = JOptionPane.showInputDialog(null, "Press (c) for Current Account or (d) for Deposit Account:", "Create New Account", JOptionPane.PLAIN_MESSAGE);
                if (accountType != null && (accountType.equalsIgnoreCase("c") || accountType.equalsIgnoreCase("d"))) {
                    String accountIdStr = JOptionPane.showInputDialog(null, "Enter Account ID:", "Create New Account", JOptionPane.PLAIN_MESSAGE);
                    if (accountIdStr != null) {
                        try {
                            int accountId = Integer.parseInt(accountIdStr);
                            if (accountType.equalsIgnoreCase("c")) {
                                CurrentAccount newAccount = new CurrentAccount(accountId, thomondAccounts.size() + 1, 0,LocalDate.now(), CurrentAccount.getAIR(), 500.0);
                                thomondAccounts.add(newAccount);
                                JOptionPane.showMessageDialog(null, "Current Account created" + accountId);
                            } else if (accountType.equalsIgnoreCase("d")) {
                                DepositAccount newAccount = new DepositAccount(accountId, thomondAccounts.size() + 1, 0,LocalDate.now());
                                thomondAccounts.add(newAccount);
                                JOptionPane.showMessageDialog(null, "Deposit Account created" + accountId);
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please press 'c' or 'd'.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        changeAirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentAccount != null) {
                    String airStr = JOptionPane.showInputDialog(null, "Enter new AIR:", "Change AIR", JOptionPane.PLAIN_MESSAGE);
                    if (airStr != null) {
                        try {
                            double newAir = Double.parseDouble(airStr);
                            CurrentAccount.setAIR(newAir);
                            JOptionPane.showMessageDialog(null, "AIR updated: " + newAir + "%");
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
                if (depositAccount != null) {
                    String airStr = JOptionPane.showInputDialog(null, "Enter new AIR:", "Change AIR", JOptionPane.PLAIN_MESSAGE);
                    if (airStr != null) {
                        try {
                            double newAir = Double.parseDouble(airStr);
                            DepositAccount.setAIR(newAir);
                            JOptionPane.showMessageDialog(null, "AIR updated: " + newAir + "%");
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }

            }
        });
        changeOverdraftLimitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    private void populateMyAccounts() {
        thomondAccounts.add(new DepositAccount(1, 1, 100,LocalDate.now()));
        thomondAccounts.add(new DepositAccount(2, 2, 500,LocalDate.now()));
        thomondAccounts.add(new DepositAccount(3, 3, 300,LocalDate.now()));
        thomondAccounts.add(new DepositAccount(4, 4, 300,LocalDate.now()));
        thomondAccounts.add(new CurrentAccount(4, 1, 100,LocalDate.now(), CurrentAccount.getAIR(), 500.0));
        thomondAccounts.add(new CurrentAccount(5, 2, 1000,LocalDate.now(), CurrentAccount.getAIR(), 500.0));
        thomondAccounts.add(new CurrentAccount(6, 4, 200,LocalDate.now(), CurrentAccount.getAIR(), 500.0));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Thomond Banks");
        frame.setContentPane(new ThomondBanks().root);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}